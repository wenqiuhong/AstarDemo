using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Summer
{
    /// <summary>
    /// 存放当前Node的位置
    /// </summary>
    public class TargetNode : MonoBehaviour
    {
        public I_Pos _pos;
    }
}